import React, { useCallback, useEffect, useState } from 'react';
import { View, Text, StyleSheet } from 'react-native';
import type { NativeStackScreenProps } from '@react-navigation/native-stack';
import { RootStackParamList } from '../navigation';
import CameraView from '../components/CameraView';
import { initDetector } from '../modules/movenet';


export default function DetectScreen({ route }: NativeStackScreenProps<RootStackParamList, 'Detect'>) {
  const { task } = route.params;
  const [ready, setReady] = useState(false);

  useEffect(() => {
    (async () => {
      console.log('[screen] ⏳ init start');
      try {
        await initDetector();
        console.log('[screen] ✅ init done');
        setReady(true);
      } catch (e) {
        console.log('[screen] ❌ init error', e);
      }
    })();
  }, []);

  const handleResult = useCallback((status: string, done: boolean) => {
    // 这里可以加入 Toast 或导航回主页面
    if (done) console.log('✅', status);
  }, []);

  if (!ready) return <Text style={styles.tip}>模型加载中…</Text>;

  return (
    <View style={styles.container}>
      <CameraView task={task} onResult={handleResult} />
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#000' },
  tip: { flex: 1, justifyContent: 'center', textAlign: 'center', fontSize: 18 },
});