// 将 Python 状态机翻译为 TS，保持原逻辑
import { Pose } from '@tensorflow-models/pose-detection';

interface State {
  taskState: 'initial' | 'hand_near_mouth' | 'hand_away' | 'arms_up';
  stateStart: number;
  absenceStart: number;
  stretchHoldStart: number;
}

const state: Record<string, State> = {};

export function detectAction(task: string, poses: Pose[]) {
  const now = Date.now();
  if (!state[task]) state[task] = {
    taskState: 'initial',
    stateStart: 0,
    absenceStart: 0,
    stretchHoldStart: 0,
  };
  const s = state[task];

  const keypoints = poses[0]?.keypoints || [];
  const get = (name: string) => keypoints.find(k => k.name === name);
  const dist = (a: any, b: any) => Math.hypot(a.x - b.x, a.y - b.y);

  let text = '检测中…';
  let done = false;

  switch (task) {
    case 'drink_water': {
      const lw = get('left_wrist');
      const rw = get('right_wrist');
      const nose = get('nose');
      if (lw && rw && nose) {
        const d = Math.min(dist(lw, nose), dist(rw, nose));
        if (s.taskState === 'initial' && d < 50) {
          s.taskState = 'hand_near_mouth';
          s.stateStart = now;
          text = '手已靠近';
        } else if (s.taskState === 'hand_near_mouth') {
          if (d < 50 && now - s.stateStart > 2000) {
            s.taskState = 'hand_away';
            text = '放下杯子';
          } else if (d > 80) {
            s.taskState = 'initial';
          }
        } else if (s.taskState === 'hand_away' && d > 80) {
          done = true;
          text = '喝水动作完成';
        }
      }
      break;
    }
    case 'leave_seat': {
      if (poses.length === 0) {
        if (!s.absenceStart) s.absenceStart = now;
        const dur = now - s.absenceStart;
        text = `离开 ${Math.floor(dur / 1000)} / 5 秒`;
        if (dur > 5000) {
          done = true;
          text = '离席完成';
        }
      } else {
        s.absenceStart = 0;
        text = '检测到坐姿';
      }
      break;
    }
    case 'stretch': {
      const lw = get('left_wrist');
      const rw = get('right_wrist');
      const ls = get('left_shoulder');
      const rs = get('right_shoulder');
      if (lw && rw && ls && rs) {
        const upL = lw.y < ls.y - 50;
        const upR = rw.y < rs.y - 50;
        if (s.taskState === 'initial' && upL && upR) {
          s.taskState = 'arms_up';
          s.stretchHoldStart = now;
          text = '保持举手…';
        } else if (s.taskState === 'arms_up') {
          if (upL && upR && now - s.stretchHoldStart > 1500) {
            done = true;
            text = '伸懒腰完成';
          } else if (!upL || !upR) {
            s.taskState = 'initial';
          }
        }
      }
      break;
    }
  }

  return { text, done };
}