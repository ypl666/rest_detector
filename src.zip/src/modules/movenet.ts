// src/modules/movenet.ts   ✅ 修正版
//--------------------------------------------------
// 1. 先注册平台（一定放第一行！）


// 2. 再导入 tf / 其他模型
import * as tf from '@tensorflow/tfjs';
import * as posedetection from '@tensorflow-models/pose-detection';
//--------------------------------------------------
import { setPlatform } from '@tensorflow/tfjs-core';

// 极简平台对象：只实现 fetch（其他用不到先不实现）
const miniPlatform = {
  fetch: (url: RequestInfo, init?: RequestInit) => global.fetch(url as any, init as any),
  now: () => Date.now(),
} as any;

setPlatform(miniPlatform);

let detector: posedetection.PoseDetector | null = null;

export async function initDetector() {
  // 1) 运行环境是否有 fetch（RN 应该是 true）
console.log('[check] global.fetch exists?', typeof global.fetch);

// 2) 当前 TFJS 看到的平台对象
try {
  // @ts-ignore 私有字段，但可以读到
  const p = (tf as any).env().platform;
  console.log('[check] tf.env().platform is undefined?', p === undefined);
  console.log('[check] tf.getBackend()', tf.getBackend());
} catch (e) {
  console.log('[check] tf.env() access error', e);
}

// 3) 当前注册的 backend 列表（是否包含 rn-webgl/cpu）
try {
  // @ts-ignore 非公开，但可用
  const reg = (tf as any).engine().registryFactory;
  console.log('[check] registered backends:', Object.keys(reg || {}));
} catch {}

  console.log('[movenet] ① set backend cpu');
  await tf.setBackend('cpu');        // ⭐ 先选后端

  console.log('[movenet] ② tf.ready() …');
  await tf.ready();                  // ⭐ 再 ready（会初始化 fetch 等平台对象）
  console.log('[movenet] ③ tf.ready() OK');

  console.log('[movenet] ④ createDetector() …');
  detector = await posedetection.createDetector(
    posedetection.SupportedModels.MoveNet,
    { modelType: 'SinglePose.Lightning', enableSmoothing: true }
  );
  console.log('[movenet] ⑤ detector 创建完成');
  return detector;
}

export async function estimatePose(tensor: tf.Tensor3D) {
  if (!detector) throw new Error('MoveNet detector not init');
  return detector.estimatePoses(tensor, { flipHorizontal: true });
}